# main.py

from flask import Flask, render_template, request, jsonify
import openai

app = Flask(__name__)

# Your ChatGPT API key
api_key = "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"

# Initialize the ChatGPT client
openai.api_key = api_key

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/generate_code', methods=['POST'])
def generate_code():
    pseudo_code = request.form['pseudo_code']

    # Call the ChatGPT API to generate Python code
    response = openai.Completion.create(
        engine="text-davinci-002",
        prompt=f"Consider the pseudo code:\n{pseudo_code}\nGenerate the complete code in Python language.",
        max_tokens=100
    )

    generated_code = response.choices[0].text

    return jsonify({"generated_code": generated_code})

if __name__ == '__main__':
    app.run(debug=True)
